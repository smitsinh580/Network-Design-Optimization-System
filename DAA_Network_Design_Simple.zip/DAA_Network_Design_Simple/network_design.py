"""
NETWORK DESIGN OPTIMIZATION SYSTEM
DAA Mini Project - 5th Semester

Problem : Connect all buildings of a college campus with network cable
          at the MINIMUM total cost.
Idea    : Buildings = vertices, possible cable links = edges, cable cost = weight.
          The cheapest way to connect everything is a Minimum Spanning Tree (MST).
Methods : 1. Kruskal's algorithm (Greedy + Union-Find)   ->  O(E log E)
          2. Prim's algorithm    (Greedy + Min-Heap)      ->  O(E log V)

Run     : python3 network_design.py
"""

import csv
import heapq
import os
import random
import sys
import time

RESULTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")

# ---------------------------------------------------------------------------
# 1. SAMPLE INPUT: college campus with 8 buildings and 14 possible cable links
#    cost of each link is in Rs. thousand
# ---------------------------------------------------------------------------
SAMPLE_BUILDINGS = ["Admin", "Library", "CSE Lab", "IT Lab",
                    "Hostel", "Canteen", "Auditorium", "Sports Ground"]

SAMPLE_LINKS = [            # (building 1, building 2, cost)
    ("Admin", "Library", 40),
    ("Admin", "Auditorium", 35),
    ("Admin", "Canteen", 55),
    ("Library", "CSE Lab", 30),
    ("Library", "Canteen", 39),
    ("CSE Lab", "IT Lab", 25),
    ("CSE Lab", "Canteen", 50),
    ("IT Lab", "Hostel", 45),
    ("IT Lab", "Canteen", 60),
    ("Canteen", "Hostel", 50),
    ("Canteen", "Auditorium", 38),
    ("Canteen", "Sports Ground", 42),
    ("Auditorium", "Sports Ground", 48),
    ("Hostel", "Sports Ground", 40),
]

# positions are used only to draw the campus picture
POSITIONS = {"Admin": (2, 6), "Library": (4, 7), "CSE Lab": (6, 7.5), "IT Lab": (8, 6.5),
             "Hostel": (8.5, 3.5), "Canteen": (5, 4.5), "Auditorium": (2.5, 3.5),
             "Sports Ground": (5.5, 1.5)}


# ---------------------------------------------------------------------------
# 2. UNION-FIND (Disjoint Set) - used by Kruskal to detect cycles
# ---------------------------------------------------------------------------
def find(parent, x):
    """Return the leader (root) of the group that contains x."""
    while parent[x] != x:
        parent[x] = parent[parent[x]]     # path compression (makes it faster)
        x = parent[x]
    return x


def union(parent, a, b):
    """Join the groups of a and b. Returns False if they were already joined."""
    root_a, root_b = find(parent, a), find(parent, b)
    if root_a == root_b:
        return False                       # same group -> adding this link makes a cycle
    parent[root_b] = root_a
    return True


# ---------------------------------------------------------------------------
# 3. KRUSKAL'S ALGORITHM
#    Sort all links by cost. Take the cheapest link that does not make a cycle.
#    Stop when we have (number of buildings - 1) links.
# ---------------------------------------------------------------------------
def kruskal(buildings, links, show_steps=False):
    parent = {b: b for b in buildings}     # every building starts in its own group
    selected, total = [], 0
    sorted_links = sorted(links, key=lambda link: link[2])     # O(E log E)

    step = 0
    for a, b, cost in sorted_links:
        if len(selected) == len(buildings) - 1:
            break                          # tree is complete
        step += 1
        if union(parent, a, b):
            selected.append((a, b, cost))
            total += cost
            if show_steps:
                print("  Step %2d: %-14s - %-14s cost %3d  -> ACCEPT" % (step, a, b, cost))
        elif show_steps:
            print("  Step %2d: %-14s - %-14s cost %3d  -> REJECT (makes a cycle)" % (step, a, b, cost))
    return selected, total


# ---------------------------------------------------------------------------
# 4. PRIM'S ALGORITHM
#    Start from one building. Every time, add the cheapest link that connects
#    a building already in the network to a building not yet in the network.
#    A min-heap (priority queue) gives us the cheapest link quickly.
# ---------------------------------------------------------------------------
def prim(buildings, links, start=None, show_steps=False):
    graph = {b: [] for b in buildings}     # adjacency list
    for a, b, cost in links:
        graph[a].append((cost, b))
        graph[b].append((cost, a))

    start = start or buildings[0]
    in_network = {start}
    heap = []                              # min-heap of (cost, from, to)
    for cost, nb in graph[start]:
        heapq.heappush(heap, (cost, start, nb))

    selected, total, step = [], 0, 0
    while heap and len(in_network) < len(buildings):
        cost, a, b = heapq.heappop(heap)   # cheapest link leaving the network
        if b in in_network:
            continue                       # both ends already connected -> skip
        in_network.add(b)
        selected.append((a, b, cost))
        total += cost
        step += 1
        if show_steps:
            print("  Step %2d: %-14s - %-14s cost %3d  -> ADD %s" % (step, a, b, cost, b))
        for c, nb in graph[b]:
            if nb not in in_network:
                heapq.heappush(heap, (c, b, nb))
    return selected, total


# ---------------------------------------------------------------------------
# 5. HELPERS: printing, drawing, random networks for testing
# ---------------------------------------------------------------------------
def print_network(buildings, links):
    print("\n  Buildings (%d): %s" % (len(buildings), ", ".join(buildings)))
    print("  Possible cable links (%d):" % len(links))
    for a, b, cost in links:
        print("     %-14s - %-14s cost %3d" % (a, b, cost))
    print("  Cost if we build ALL links = %d" % sum(c for _, _, c in links))


def print_result(name, buildings, links, selected, total):
    all_cost = sum(c for _, _, c in links)
    print("\n  RESULT (%s)" % name)
    print("  Links to build:")
    for a, b, cost in selected:
        print("     %-14s - %-14s cost %3d" % (a, b, cost))
    print("  Number of links      = %d (always buildings - 1 = %d)" % (len(selected), len(buildings) - 1))
    print("  MINIMUM TOTAL COST   = %d" % total)
    print("  Cost of ALL links    = %d" % all_cost)
    print("  Money saved          = %d (%.1f%%)" % (all_cost - total, 100.0 * (all_cost - total) / all_cost))
    if len(selected) < len(buildings) - 1:
        print("  WARNING: some buildings cannot be connected (network is disconnected)")


def draw_network(links, selected, filename, title):
    """Save a picture: grey = possible links, green = selected (MST) links."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    chosen = {frozenset((a, b)) for a, b, _ in selected}
    fig, ax = plt.subplots(figsize=(9, 6.5))
    for a, b, cost in links:
        (x1, y1), (x2, y2) = POSITIONS[a], POSITIONS[b]
        ok = frozenset((a, b)) in chosen
        ax.plot([x1, x2], [y1, y2], color="#16a34a" if ok else "#cbd5e1",
                linewidth=4 if ok else 1.5, zorder=1)
        ax.text((x1 + x2) / 2, (y1 + y2) / 2, str(cost), fontsize=10, ha="center", va="center",
                color="#15803d" if ok else "#64748b", fontweight="bold" if ok else "normal",
                bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none"), zorder=3)
    for name, (x, y) in POSITIONS.items():
        ax.scatter(x, y, s=500, color="#0f766e", zorder=4, edgecolors="white", linewidths=2)
        ax.text(x, y - 0.45, name, ha="center", va="top", fontsize=11, fontweight="bold", zorder=5)
    total = sum(c for _, _, c in selected)
    ax.set_title(title + ("   (total cost = %d)" % total if selected else ""), fontsize=13,
                 fontweight="bold")
    ax.axis("off")
    ax.set_xlim(1, 9.5)
    ax.set_ylim(0.5, 8.2)
    fig.tight_layout()
    fig.savefig(filename, dpi=150)
    plt.close(fig)
    print("  Picture saved: results/%s" % os.path.basename(filename))


def random_network(n, links_per_building=4, seed=1):
    """Random connected network with n buildings (used for performance testing)."""
    rnd = random.Random(seed)
    buildings = ["B%d" % i for i in range(n)]
    links, used = [], set()
    for i in range(1, n):                  # first make sure every building is reachable
        j = rnd.randrange(i)
        links.append((buildings[i], buildings[j], rnd.randint(1, 1000)))
        used.add((j, i))
    while len(links) < n * links_per_building // 2:
        i, j = rnd.randrange(n), rnd.randrange(n)
        if i != j and (min(i, j), max(i, j)) not in used:
            used.add((min(i, j), max(i, j)))
            links.append((buildings[i], buildings[j], rnd.randint(1, 1000)))
    return buildings, links


def measure(func, buildings, links, repeat=5):
    """Average running time in milliseconds."""
    start = time.perf_counter()
    for _ in range(repeat):
        _, total = func(buildings, links)
    return (time.perf_counter() - start) * 1000 / repeat, total


def compare_performance(sizes=(10, 50, 100, 500, 1000, 2000)):
    os.makedirs(RESULTS, exist_ok=True)
    rows = []
    print("\n  Testing both algorithms on random networks of different sizes...")
    print("  %-12s %-10s %-16s %-16s %s" % ("Buildings", "Links", "Kruskal (ms)", "Prim (ms)", "Same cost?"))
    for n in sizes:
        b, l = random_network(n, seed=n)
        tk, ck = measure(kruskal, b, l)
        tp, cp = measure(prim, b, l)
        rows.append((n, len(l), round(tk, 3), round(tp, 3), ck == cp))
        print("  %-12d %-10d %-16.3f %-16.3f %s" % (n, len(l), tk, tp, "YES" if ck == cp else "NO"))

    with open(os.path.join(RESULTS, "performance.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["buildings_V", "links_E", "kruskal_ms", "prim_ms", "same_cost"])
        w.writerows(rows)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot([r[0] for r in rows], [r[2] for r in rows], "o-", lw=2.5, color="#2563eb", label="Kruskal")
    ax.plot([r[0] for r in rows], [r[3] for r in rows], "s-", lw=2.5, color="#16a34a", label="Prim")
    ax.set_xlabel("Input size (number of buildings)")
    ax.set_ylabel("Execution time (ms)")
    ax.set_title("Input Size vs Execution Time", fontweight="bold")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    path = os.path.join(RESULTS, "performance_graph.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print("\n  Table saved : results/performance.csv")
    print("  Graph saved : results/performance_graph.png")
    return rows


def enter_own_network():
    """Let the user type their own buildings and links."""
    n = int(input("  How many buildings? "))
    buildings = [input("  Name of building %d: " % (i + 1)).strip() for i in range(n)]
    m = int(input("  How many possible links? "))
    links = []
    print("  Enter each link as:  building1,building2,cost")
    for i in range(m):
        a, b, c = [x.strip() for x in input("  Link %d: " % (i + 1)).split(",")]
        if a not in buildings or b not in buildings:
            print("  Unknown building name, link skipped")
            continue
        links.append((a, b, int(c)))
    return buildings, links


# ---------------------------------------------------------------------------
# 6. MAIN MENU
# ---------------------------------------------------------------------------
def main():
    buildings, links = SAMPLE_BUILDINGS, SAMPLE_LINKS
    os.makedirs(RESULTS, exist_ok=True)
    while True:
        print("\n" + "=" * 58)
        print("        NETWORK DESIGN OPTIMIZATION SYSTEM (MST)")
        print("=" * 58)
        print("  1. Show campus network (input)")
        print("  2. Run Kruskal's algorithm (step by step)")
        print("  3. Run Prim's algorithm (step by step)")
        print("  4. Compare Kruskal vs Prim (performance test)")
        print("  5. Enter my own network")
        print("  6. Save pictures of the network")
        print("  0. Exit")
        choice = input("  Enter your choice: ").strip()

        if choice == "1":
            print_network(buildings, links)
        elif choice == "2":
            print("\n  KRUSKAL: sort links by cost, accept a link only if it does not make a cycle")
            sel, total = kruskal(buildings, links, show_steps=True)
            print_result("Kruskal", buildings, links, sel, total)
        elif choice == "3":
            print("\n  PRIM: start from %s, always add the cheapest link to a new building" % buildings[0])
            sel, total = prim(buildings, links, show_steps=True)
            print_result("Prim", buildings, links, sel, total)
        elif choice == "4":
            compare_performance()
        elif choice == "5":
            buildings, links = enter_own_network()
            print_network(buildings, links)
        elif choice == "6":
            if any(b not in POSITIONS for b in buildings):
                print("  Pictures are available for the sample campus only")
                continue
            draw_network(links, [], os.path.join(RESULTS, "campus_all_links.png"), "Campus - all possible links")
            sel, _ = kruskal(buildings, links)
            draw_network(links, sel, os.path.join(RESULTS, "campus_mst.png"), "Campus - minimum cost network (MST)")
        elif choice == "0":
            print("  Thank you!")
            break
        else:
            print("  Invalid choice, try again")


if __name__ == "__main__":
    main()
