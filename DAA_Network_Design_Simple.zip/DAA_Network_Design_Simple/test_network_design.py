"""Test cases for the Network Design Optimization System.
Run: python3 test_network_design.py
"""
import unittest

from network_design import SAMPLE_BUILDINGS, SAMPLE_LINKS, kruskal, prim, random_network


class TestNetworkDesign(unittest.TestCase):

    def test_1_sample_campus(self):
        """Sample campus: both algorithms must give cost 249 with 7 links."""
        sel_k, cost_k = kruskal(SAMPLE_BUILDINGS, SAMPLE_LINKS)
        sel_p, cost_p = prim(SAMPLE_BUILDINGS, SAMPLE_LINKS)
        self.assertEqual(cost_k, 249)
        self.assertEqual(cost_p, 249)
        self.assertEqual(len(sel_k), 7)
        self.assertEqual(len(sel_p), 7)

    def test_2_triangle(self):
        """3 buildings in a triangle: the most expensive link is left out."""
        b = ["A", "B", "C"]
        l = [("A", "B", 1), ("B", "C", 2), ("A", "C", 3)]
        self.assertEqual(kruskal(b, l)[1], 3)
        self.assertEqual(prim(b, l)[1], 3)

    def test_3_single_building(self):
        """Only one building: nothing to connect, cost 0."""
        self.assertEqual(kruskal(["A"], [])[1], 0)
        self.assertEqual(prim(["A"], [])[1], 0)

    def test_4_equal_costs(self):
        """All links have the same cost: any tree of 3 links, cost 15."""
        b = ["A", "B", "C", "D"]
        l = [("A", "B", 5), ("B", "C", 5), ("C", "D", 5), ("D", "A", 5)]
        self.assertEqual(kruskal(b, l)[1], 15)
        self.assertEqual(prim(b, l)[1], 15)

    def test_5_disconnected(self):
        """Two separate groups: the network cannot be fully connected."""
        b = ["A", "B", "C", "D"]
        l = [("A", "B", 1), ("C", "D", 2)]
        self.assertEqual(len(kruskal(b, l)[0]), 2)     # less than 3 links
        self.assertEqual(len(prim(b, l)[0]), 1)        # Prim only reaches A-B from start A

    def test_6_random_networks_same_answer(self):
        """On 20 random networks Kruskal and Prim must find the same minimum cost."""
        for seed in range(20):
            b, l = random_network(50 + seed * 10, seed=seed)
            self.assertEqual(kruskal(b, l)[1], prim(b, l)[1])

    def test_7_large_network(self):
        """Large network (2000 buildings): result has exactly V - 1 links."""
        b, l = random_network(2000, seed=7)
        self.assertEqual(len(kruskal(b, l)[0]), 1999)
        self.assertEqual(len(prim(b, l)[0]), 1999)


if __name__ == "__main__":
    unittest.main(verbosity=2)
